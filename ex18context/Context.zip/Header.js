import React from 'react';
import HeaderButton from './HeaderButton';

function Header() {
  return (
    <div>
      <HeaderButton />
    </div> 
  );
}

export default Header;